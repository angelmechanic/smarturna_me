<?php
require_once __DIR__ . '/../lib/auth.php';
require_votante();
$cfg = require __DIR__ . '/../config.php';
$pdo = db();
$me = current_votante();

// Cargar elección activa
$st = $pdo->prepare('SELECT * FROM elecciones WHERE id=? AND activa=1');
$st->execute([$cfg['app']['eleccion_activa_id']]);
$eleccion = $st->fetch();
if (!$eleccion) {
  http_response_code(503);
  exit('No hay elección activa configurada.');
}

// Obtener listas activas de esta elección
$st_listas = $pdo->prepare('SELECT id, nombre FROM listas WHERE eleccion_id = ? AND activa = 1');
$st_listas->execute([$eleccion['id']]);
$nombres_listas = [];
while ($l = $st_listas->fetch()) {
  $nombres_listas[$l['id']] = $l['nombre'];
}

// Si no hay listas activas, no se puede votar
if (count($nombres_listas) === 0) {
  http_response_code(503);
  exit('No hay listas activas en esta elección.');
}

// Obtener candidatos de esas listas activas
$placeholders = implode(',', array_fill(0, count($nombres_listas), '?'));
$params = array_keys($nombres_listas);
array_unshift($params, $eleccion['id']); // eleccion_id va primero

$sc = $pdo->prepare(
  "SELECT * FROM candidatos WHERE eleccion_id = ? AND lista_id IN ($placeholders) ORDER BY nombre"
);
$sc->execute($params);
$candidatos_raw = $sc->fetchAll();

// Agrupar candidatos por lista_id
$listas = [];
foreach ($candidatos_raw as $c) {
  $listas[$c['lista_id']][] = $c;
}

// Detectar si es plebiscito
$es_plebiscito = count($nombres_listas) === 1;
$unica_lista_id = array_key_first($nombres_listas);
$nombre_lista = $nombres_listas[$unica_lista_id] ?? 'Lista única';
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Votar - <?= htmlspecialchars($cfg['app']['name']) ?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header><div class="container"><h2>Boleta: <?= htmlspecialchars($eleccion['nombre']) ?></h2></div></header>
<main class="container">
  <?php if ($me['ha_votado']): ?>
    <div class="card notice">
      <strong>Registro existente:</strong> Nuestro sistema indica que ya emitiste tu voto. Si crees que es un error, informa a TRICEL.
    </div>
  <?php else: ?>
    <div class="card">
      <h3>Hola, <?= htmlspecialchars($me['nombre']) ?></h3>

      <?php if ($es_plebiscito): ?>
        <p><strong>¿Aceptas que la <?= htmlspecialchars($nombre_lista) ?> asuma el cargo?</strong></p>
        <ul>
          <?php foreach ($listas[$unica_lista_id] as $c): ?>
            <li><?= htmlspecialchars($c['nombre']) ?> – <strong><?= htmlspecialchars($c['cargo']) ?></strong>
              <?php if ($c['descripcion']): ?><br><small><?= htmlspecialchars($c['descripcion']) ?></small><?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>

        <form method="post" action="votar_post.php">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="eleccion_id" value="<?= (int)$eleccion['id'] ?>">
          <button class="btn green" name="plebiscito" value="si">✅ Sí, acepto</button>
          <button class="btn red" name="plebiscito" value="no">❌ No, rechazo</button>
        </form>

      <?php else: ?>
        <form method="post" action="votar_post.php">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="eleccion_id" value="<?= (int)$eleccion['id'] ?>">

          <?php foreach ($listas as $id_lista => $candidatos): ?>
            <label class="tarjeta-lista">
              <input type="radio" name="lista" value="<?= htmlspecialchars($id_lista) ?>" required>
              <div class="contenido-lista">
                <span class="nombre-lista">Lista <?= htmlspecialchars($nombres_listas[$id_lista] ?? "ID $id_lista") ?></span>
                <ul class="candidatos">
                  <?php foreach ($candidatos as $c): ?>
                    <li>
                      <?= htmlspecialchars($c['nombre']) ?> – <strong><?= htmlspecialchars($c['cargo']) ?></strong>
                      <?php if (!empty($c['descripcion'])): ?>
                        <br><span class="cargo"><?= htmlspecialchars($c['descripcion']) ?></span>
                      <?php endif; ?>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>
            </label>
          <?php endforeach; ?>

          <div style="margin-top: 16px;">
            <button class="btn" type="submit">Confirmar voto</button>
          </div>
        </form>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</main>
</body>
<?php require_once __DIR__ . '/montti.php'; ?>

</html>
