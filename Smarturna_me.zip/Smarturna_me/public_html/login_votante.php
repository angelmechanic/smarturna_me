<?php
require_once __DIR__ . '/../lib/auth.php';
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
    exit('CSRF inválido');
  }

  $rut = trim($_POST['rut'] ?? '');
  $pin = trim($_POST['pin'] ?? '');

  if (!$rut || !$pin) {
    exit('RUT y PIN son obligatorios.');
  }

  $stmt = $pdo->prepare("SELECT * FROM votantes WHERE rut = ?");
  $stmt->execute([$rut]);
  $votante = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$votante || !password_verify($pin, $votante['pin_hash'])) {
    exit('❌ RUT o PIN incorrecto.');
  }

  if ((int)$votante['ha_votado'] === 1) {
    echo <<<HTML
    <!doctype html>
    <html lang="es">
    <head>
      <meta charset="utf-8">
      <title>Ya votaste</title>
      <link rel="stylesheet" href="assets/style.css">
    </head>
    <body>
    <main class="container">
      <div class="card">
        <h2>⚠️ Ya has votado</h2>
        <p>Este RUT ya fue registrado como votante. No puedes votar nuevamente.</p>
        <a class="btn" href="index.php">Volver</a>
      </div>
    </main>
    </body>
    </html>
    HTML;
    exit;
  }

  // Login exitoso
  $_SESSION['votante_id'] = $votante['id'];
  header('Location: votar.php');
  exit;
}

header('Location: index.php');
exit;
