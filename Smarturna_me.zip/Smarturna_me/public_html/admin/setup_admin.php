<?php
require_once __DIR__ . '/../../lib/auth.php';
$pdo = db();
$exists = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0;
if ($exists) { exit('Ya existen administradores.'); }
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) { exit('CSRF inválido.'); }
  $u = trim($_POST['usuario'] ?? '');
  $p = trim($_POST['pass'] ?? '');
  if ($u && $p) {
    $st = $pdo->prepare('INSERT INTO admins (usuario, pass_hash, creado_en) VALUES (?, ?, NOW())');
    $st->execute([$u, password_hash($p, PASSWORD_DEFAULT)]);
    $msg = 'Admin creado. Ahora puedes iniciar sesión.';
  }
}
?>
<!doctype html><html lang="es"><head>
<meta charset="utf-8"><title>Crear Admin</title>
<link rel="stylesheet" href="../assets/style.css"></head><body>
<main class="container">
  <div class="card">
    <h2>Crear administrador inicial</h2>
    <?php if ($msg): ?><div class="success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <label>Usuario</label><input class="input" name="usuario" required>
      <label>Contraseña</label><input class="input" type="password" name="pass" required>
      <button class="btn" style="margin-top:12px">Crear</button>
    </form>
  </div>

<?php
$montti_path = __DIR__ . '/../montti.php';
if (file_exists($montti_path)) require $montti_path;
?>

</main></body></html>
