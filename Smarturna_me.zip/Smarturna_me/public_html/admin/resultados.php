<?php
require_once __DIR__ . '/../../lib/auth.php';
require_admin();
$cfg = require __DIR__ . '/../../config.php';
$pdo = db();

if (!$pdo) {
    die("Error de conexión a la base de datos.");
}

$total_votantes = (int)$pdo->query("SELECT COUNT(*) FROM votantes")->fetchColumn();
$votaron = (int)$pdo->query("SELECT COUNT(*) FROM votantes WHERE ha_votado = 1")->fetchColumn();
$no_votaron = $total_votantes - $votaron;
$porcentaje_voto = $total_votantes > 0 ? round(($votaron / $total_votantes) * 100, 2) : 0;

$st = $pdo->query("SELECT e.nombre AS eleccion, l.nombre AS lista, COUNT(v.id) AS votos FROM votos v JOIN listas l ON v.lista_id = l.id JOIN elecciones e ON v.eleccion_id = e.id GROUP BY v.lista_id, e.nombre, l.nombre");
if (!$st) {
    die("Error al ejecutar la consulta.");
}

$rows = $st->fetchAll(PDO::FETCH_ASSOC);
$rows[] = [
    'eleccion' => $rows[0]['eleccion'] ?? 'Desconocida',
    'lista' => 'No votaron',
    'votos' => $no_votaron
];

foreach ($rows as &$r) {
    $r['porcentaje'] = $total_votantes > 0 ? round(($r['votos'] / $total_votantes) * 100, 2) : 0;
}
unset($r);
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Resultados</title>
  <link rel="stylesheet" href="../assets/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    #graficoPastel {
      max-width: 350px;
      max-height: 350px;
      margin: 0 auto;
      display: block;
    }
    .card strong { font-size: 20px; }
    .porcentaje { color: #555; font-weight: normal; font-size: 14px; }
    .legend { margin-top: 20px; font-size: 14px; color: #333; }
  </style>
</head>
<body>
<main class="container">
  <form method="post" action="exportar_excel.php" style="margin-bottom: 20px;">
    <button class="btn">📥 Exportar a Excel</button>
  </form>

  <div class="card">
    <h2>Resultados por lista</h2>
    <p><strong>Participación:</strong> <?= $votaron ?> de <?= $total_votantes ?> votaron (<span class="porcentaje"><?= $porcentaje_voto ?>%</span>)</p>
    <table>
      <thead>
        <tr><th>Elección</th><th>Lista</th><th>Votos</th><th>% del padrón</th></tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
        <tr>
          <td><?= htmlspecialchars($r['eleccion']) ?></td>
          <td><?= htmlspecialchars($r['lista']) ?></td>
          <td><?= (int)$r['votos'] ?></td>
          <td><?= number_format($r['porcentaje'], 2) ?>%</td>
        </tr>
        <?php endforeach; ?>
        <tr>
          <th colspan="2">Total del padrón</th>
          <th colspan="2"><?= $total_votantes ?> personas</th>
        </tr>
      </tbody>
    </table>
  </div>

  <div class="card">
    <h3>Distribución por Lista</h3>
    <canvas id="graficoPastel" width="400" height="400"></canvas>
  </div>
</main>

<script>
  const data = <?= json_encode($rows) ?>;
  const labels = data.map(item => `${item.lista} (${item.porcentaje}%)`);
  const votos = data.map(item => item.votos);
  const backgroundColors = ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#2ECC71', '#E67E22', '#34495E'];

  new Chart(document.getElementById('graficoPastel'), {
    type: 'pie',
    data: {
      labels: labels,
      datasets: [{
        label: 'Votos por lista',
        data: votos,
        backgroundColor: backgroundColors.slice(0, votos.length),
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { position: 'right' },
        title: { display: true, text: 'Distribución de votos y abstenciones' }
      }
    }
  });
</script>

<?php
$montti_path = __DIR__ . '/../montti.php';
if (file_exists($montti_path)) require $montti_path;
?>
</body>
</html>
