<?php
require_once __DIR__ . '/../../lib/auth.php';
require_admin();
$pdo = db();
$msg = '';

// Procesar acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) exit('CSRF inválido');
  
  if (isset($_POST['accion'])) {
    $accion = $_POST['accion'];
    $rut = trim($_POST['rut'] ?? '');
    $nombre = trim($_POST['nombre'] ?? '');
    $curso = trim($_POST['curso'] ?? '');

    if ($accion === 'agregar' && $rut && $nombre && $curso) {
      $pin = substr(str_replace(['.', '-'], '', $rut), 0, 4);
      $st = $pdo->prepare('INSERT INTO votantes (rut, nombre, curso, pin_hash, ha_votado) VALUES (?,?,?,?,0)
        ON DUPLICATE KEY UPDATE nombre=VALUES(nombre), curso=VALUES(curso), pin_hash=VALUES(pin_hash)');
      $st->execute([$rut, $nombre, $curso, password_hash($pin, PASSWORD_DEFAULT)]);
      $msg = "Estudiante agregado o actualizado.";

    } elseif ($accion === 'eliminar_estudiante' && $rut) {
      $st = $pdo->prepare('DELETE FROM votantes WHERE rut = ?');
      $st->execute([$rut]);
      $msg = "Estudiante eliminado.";

    } elseif ($accion === 'eliminar_curso' && $curso) {
      $st = $pdo->prepare('DELETE FROM votantes WHERE curso = ?');
      $st->execute([$curso]);
      $msg = "Curso completo eliminado.";
    }
  }

  if (isset($_FILES['csv'])) {
    $tmp = $_FILES['csv']['tmp_name'];
    $fh = fopen($tmp, 'r');
    $count = 0;
    while (($row = fgetcsv($fh, 1000, ',')) !== false) {
      if (count($row) < 4) continue;
      [$rut, $nombre, $curso, $pin] = $row;
      $rut = trim($rut);
      $nombre = trim($nombre);
      $curso = trim($curso);
      $pin = trim($pin);
      if (!$rut || !$pin) continue;
      $st = $pdo->prepare('INSERT INTO votantes (rut, nombre, curso, pin_hash, ha_votado) VALUES (?,?,?,?,0)
        ON DUPLICATE KEY UPDATE nombre=VALUES(nombre), curso=VALUES(curso), pin_hash=VALUES(pin_hash)');
      $st->execute([$rut, $nombre, $curso, password_hash($pin, PASSWORD_DEFAULT)]);
      $count++;
    }
    fclose($fh);
    $msg = "Padrón cargado/actualizado: $count registros.";
  }
}

$cursoFiltro = $_GET['curso'] ?? '';
$param = $cursoFiltro ? "%$cursoFiltro%" : '%';
$st = $pdo->prepare('SELECT id, rut, nombre, curso, ha_votado FROM votantes WHERE curso LIKE ? ORDER BY curso, nombre');
$st->execute([$param]);
$padron = $st->fetchAll();

$basica = [];
$media = [];
foreach ($padron as $p) {
  $curso = strtoupper(trim($p['curso']));
  $numeroCurso = (int)filter_var($curso, FILTER_SANITIZE_NUMBER_INT);
  if ($numeroCurso >= 5 && $numeroCurso <= 8) {
    $basica[$curso][] = $p;
  } else {
    $media[$curso][] = $p;
  }
}
ksort($basica);
ksort($media);
?>

<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Padrón</title>
<link rel="stylesheet" href="../assets/style.css">
<style>
  summary { cursor: pointer; font-weight: bold; margin: 10px 0; }
</style>
</head>
<body>
<main class="container">
  <div class="card">
    <h2>Cargar padrón (CSV)</h2>
    <?php if ($msg): ?><div class="success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input type="file" name="csv" accept=".csv" required>
      <button class="btn">Subir archivo CSV</button>
    </form>
    <p>Formato: <code>rut,nombre,curso,pin</code></p>
  </div>

  <div class="card">
    <h3>Gestor de estudiantes</h3>
    <form method="post" class="form-grid">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <input class="input" name="rut" placeholder="RUT del estudiante">
      <input class="input" name="nombre" placeholder="Nombre completo">
      <input class="input" name="curso" placeholder="Curso (Ej: 2ºA)">
      <select name="accion" class="input">
        <option value="agregar">Agregar o actualizar estudiante</option>
        <option value="eliminar_estudiante">Eliminar estudiante</option>
        <option value="eliminar_curso">Eliminar curso completo</option>
      </select>
      <button class="btn">Ejecutar acción</button>
    </form>
    <p>El PIN se genera automáticamente con los primeros 4 dígitos del RUT.</p>
  </div>

  <div class="card">
    <h3>Filtrar por curso</h3>
    <form method="get">
      <input class="input" type="text" name="curso" placeholder="Ej: 3ºB" value="<?= htmlspecialchars($cursoFiltro) ?>">
      <button class="btn">Filtrar</button>
    </form>
  </div>

  <div class="card">
    <details open>
      <summary>Educación Básica (<?= array_sum(array_map('count', $basica)) ?> registros)</summary>
      <?php foreach ($basica as $curso => $estudiantes): ?>
        <details>
          <summary><?= htmlspecialchars($curso) ?> (<?= count($estudiantes) ?>)</summary>
          <table>
            <thead><tr><th>Curso</th><th>RUT</th><th>Nombre</th><th>Voto</th></tr></thead>
            <tbody>
              <?php foreach ($estudiantes as $p): ?>
                <tr>
                  <td><?= htmlspecialchars($p['curso']) ?></td>
                  <td><?= htmlspecialchars($p['rut']) ?></td>
                  <td><?= htmlspecialchars($p['nombre']) ?></td>
                  <td><?= $p['ha_votado'] ? 'Emitido' : 'Pendiente' ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </details>
      <?php endforeach; ?>
    </details>
  </div>

  <div class="card">
    <details>
      <summary>Educación Media (<?= array_sum(array_map('count', $media)) ?> registros)</summary>
      <?php foreach ($media as $curso => $estudiantes): ?>
        <details>
          <summary><?= htmlspecialchars($curso) ?> (<?= count($estudiantes) ?>)</summary>
          <table>
            <thead><tr><th>Curso</th><th>RUT</th><th>Nombre</th><th>Voto</th></tr></thead>
            <tbody>
              <?php foreach ($estudiantes as $p): ?>
                <tr>
                  <td><?= htmlspecialchars($p['curso']) ?></td>
                  <td><?= htmlspecialchars($p['rut']) ?></td>
                  <td><?= htmlspecialchars($p['nombre']) ?></td>
                  <td><?= $p['ha_votado'] ? 'Emitido' : 'Pendiente' ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </details>
      <?php endforeach; ?>
    </details>
  </div>
</main>

<?php
$montti_path = __DIR__ . '/../montti.php';
if (file_exists($montti_path)) require $montti_path;
?>

</body>
</html>
