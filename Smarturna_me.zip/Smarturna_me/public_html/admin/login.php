<?php
require_once __DIR__ . '/../../lib/auth.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
    $err = 'CSRF inválido.';
  } else {
    $u = trim($_POST['usuario'] ?? '');
    $p = trim($_POST['pass'] ?? '');
    if (login_admin($u, $p)) {
      header('Location: ' . base_url('/admin/index.php'));
      exit;
    } else {
      $err = 'Credenciales inválidas.';
    }
  }
}
?>
<!doctype html><html lang="es"><head>
<meta charset="utf-8"><title>Admin - Login</title>
<link rel="stylesheet" href="../assets/style.css">
</head><body>
<main class="container">
  <div class="card">
    <h2>Acceso Administración</h2>
    <?php if ($err): ?><div class="error" style="margin:10px 0;"><?= htmlspecialchars($err) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <label>Usuario</label><input class="input" name="usuario" required>
      <label>Contraseña</label><input class="input" type="password" name="pass" required>
      <div style="margin-top:12px"><button class="btn secondary">Entrar</button></div>
    </form>
    <p style="margin-top:8px">¿Primera vez? Si no existe ningún administrador, crea uno aquí: <a href="setup_admin.php">crear admin inicial</a>.</p>
  </div>
  
<?php
$montti_path = __DIR__ . '/../montti.php';
if (file_exists($montti_path)) require $montti_path;
?>

</main></body></html>
