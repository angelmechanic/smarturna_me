<?php
require_once __DIR__ . '/../../lib/auth.php';
require_admin();
$pdo = db();
$msg = '';

// Eliminar elección (seguro)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar_id'])) {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) exit('CSRF inválido');
  $eliminarId = (int)$_POST['eliminar_id'];

  // Verificar si está activa
  $check = $pdo->prepare('SELECT activa FROM elecciones WHERE id=?');
  $check->execute([$eliminarId]);
  $elec = $check->fetch();
  if ($elec && (int)$elec['activa'] === 1) {
    $msg = '⚠️ No puedes eliminar una elección activa.';
  } else {
    $pdo->prepare('DELETE FROM elecciones WHERE id=?')->execute([$eliminarId]);
    $msg = 'Elección eliminada.';
  }
}

// Crear o actualizar
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre']) && !isset($_POST['eliminar_id'])) {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) exit('CSRF inválido');
  $nombre = trim($_POST['nombre'] ?? '');
  $activa = isset($_POST['activa']) ? 1 : 0;
  $id = (int)($_POST['id'] ?? 0);

  if ($id) {
    $st = $pdo->prepare('UPDATE elecciones SET nombre=?, activa=? WHERE id=?');
    $st->execute([$nombre, $activa, $id]);
    if ($activa) {
      $pdo->exec('UPDATE elecciones SET activa=0 WHERE id!=' . (int)$id);
    }
    $msg = 'Elección actualizada.';
  } else {
    $st = $pdo->prepare('INSERT INTO elecciones (nombre, activa, creada_en) VALUES (?, ?, NOW())');
    $st->execute([$nombre, $activa]);
    $id = (int)$pdo->lastInsertId();
    if ($activa) {
      $pdo->exec('UPDATE elecciones SET activa=0 WHERE id!=' . (int)$id);
    }
    $msg = 'Elección creada.';
  }
}

// Traer elecciones
$elecciones = $pdo->query('SELECT * FROM elecciones ORDER BY id DESC')->fetchAll();

// Modo edición
$editando = null;
if (isset($_GET['id'])) {
  $idEdit = (int)$_GET['id'];
  $st = $pdo->prepare('SELECT * FROM elecciones WHERE id = ?');
  $st->execute([$idEdit]);
  $editando = $st->fetch();
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Elección</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<main class="container">
  <div class="card">
    <h2><?= $editando ? 'Editar elección' : 'Nueva elección' ?></h2>
    <?php if ($msg): ?><div class="success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <?php if ($editando): ?>
        <input type="hidden" name="id" value="<?= (int)$editando['id'] ?>">
      <?php endif; ?>
      <label>Nombre</label>
      <input class="input" name="nombre" required value="<?= htmlspecialchars($editando['nombre'] ?? '') ?>">
      <label>
      <input type="hidden" name="activa" value="0">
      <input type="checkbox" name="activa" value="1" <?= isset($editando) && (int)$editando['activa'] === 1 ? 'checked' : '' ?>>
        Marcar como activa
      </label>
      <button class="btn" style="margin-top:10px"><?= $editando ? 'Actualizar' : 'Guardar' ?></button>
    </form>
  </div>

  <div class="card">
    <h3>Listado de elecciones</h3>
    <table>
      <thead>
        <tr><th>ID</th><th>Nombre</th><th>Activa</th><th>Acciones</th></tr>
      </thead>
      <tbody>
        <?php foreach($elecciones as $e): ?>
          <tr>
            <td><?= (int)$e['id'] ?></td>
            <td><?= htmlspecialchars($e['nombre']) ?></td>
            <td><?= ((int)$e['activa']) === 1 ? 'Sí' : 'No' ?></td>
            <td>
              <a class="btn secondary" href="?id=<?= (int)$e['id'] ?>">Editar</a>
              <?php if (!$e['activa']): ?>
                <form method="post" style="display:inline" onsubmit="return confirm('¿Seguro que deseas eliminar esta elección?');">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                  <input type="hidden" name="eliminar_id" value="<?= (int)$e['id'] ?>">
                  <button class="btn" style="background:#cc0000;margin-left:8px">Eliminar</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</main>

<?php
$montti_path = __DIR__ . '/../montti.php';
if (file_exists($montti_path)) require $montti_path;
?>

</body>
</html>
