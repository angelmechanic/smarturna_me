<?php
require_once __DIR__ . '/../../lib/auth.php';
require_admin();
$cfg = require __DIR__ . '/../../config.php';
$pdo = db();
$padron = (int)$pdo->query('SELECT COUNT(*) FROM votantes')->fetchColumn();
$cands = (int)$pdo->query('SELECT COUNT(*) FROM candidatos')->fetchColumn();
$votos = (int)$pdo->query('SELECT COUNT(*) FROM votos')->fetchColumn();
$listas = (int)$pdo->query('SELECT COUNT(*) FROM listas')->fetchColumn();
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Admin - Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="https://unpkg.com/driver.js/dist/driver.min.css">
  <script src="https://unpkg.com/driver.js/dist/driver.min.js"></script>
  <style>
    .logo-carousel {
      position: absolute;
      top: 10px;
      right: 10px;
      width: 80px;
      height: 80px;
      z-index: 10;
    }
    .logo-carousel img {
      position: absolute;
      width: 100%;
      height: auto;
      opacity: 0;
      transition: opacity 0.6s ease-in-out;
    }
    .logo-carousel img.active {
      opacity: 1;
    }

    .btn {
      display: inline-block;
      margin: 6px;
      padding: 12px 20px;
      border-radius: 6px;
      text-decoration: none;
      background-color: #007bff;
      color: white;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
      position: relative;
    }

    .btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 10px rgba(0, 0, 0, 0.25);
    }

    .btn.secondary {
      background-color: #6c757d;
    }

    .btn::after {
      content: attr(data-tooltip);
      position: absolute;
      background-color: #333;
      color: #fff;
      padding: 6px 10px;
      border-radius: 4px;
      font-size: 12px;
      white-space: nowrap;
      bottom: 120%;
      left: 50%;
      transform: translateX(-50%);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.2s ease;
    }

    .btn:hover::after {
      opacity: 1;
    }

    .card strong { font-size: 18px; }
    .card div { font-size: 24px; font-weight: bold; margin-top: 5px; }

    .row {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 24px;
    }

    .col {
      flex: 1 1 180px;
    }

    #montti-container {
      position: fixed;
      bottom: 0;
      left: 0;
      margin: 10px;
      z-index: 1000;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    #montti-container img {
      width: 80px;
    }

    #montti-tip {
      background: #fff;
      color: #000;
      border: 1px solid #ccc;
      border-radius: 6px;
      padding: 6px 12px;
      font-size: 14px;
      margin-top: 5px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }

    @media (max-width: 768px) {
      .btn {
        display: block;
        width: 100%;
        text-align: center;
        margin-bottom: 12px;
      }
      .logo-carousel {
        width: 60px;
        height: 60px;
        top: 6px;
        right: 6px;
      }
    }
  </style>
</head>
<body>
<header>
  <div class="container" style="position:relative;">
    <h2>Panel de Administración</h2>
    <div class="logo-carousel">
      <img src="../assets/img/Logo_colegio_ebm.png" class="active" alt="Logo Colegio">
      <img src="../assets/img/color-programacion.png" alt="Logo Programación">
      <img src="../assets/img/Color-Gastronomia.png" alt="Logo Gastronomía">
      <img src="../assets/img/Color-HC-2.png" alt="Logo HC">
      <img src="../assets/img/Color-Instalaciones.png" alt="Logo Instalaciones">
    </div>
  </div>
</header>

<main class="container">
  <div class="row">
    <div class="col"><div class="card"><strong>Padrón</strong><div><?= $padron ?> votantes</div></div></div>
    <div class="col"><div class="card"><strong>Candidatos</strong><div><?= $cands ?> registrados</div></div></div>
    <div class="col"><div class="card"><strong>Votos emitidos</strong><div><?= $votos ?> en total</div></div></div>
    <div class="col"><div class="card"><strong>Listas</strong><div><?= $listas ?> registradas</div></div></div>
  </div>

  <div class="card">
    <a id="btn-padron" class="btn" href="padron.php" data-tooltip="Cargar o editar el padrón de votantes">📋 Padrón</a>
    <a id="btn-candidatos" class="btn" href="candidatos.php" data-tooltip="Agregar, editar o eliminar candidatos">👥 Candidatos</a>
    <a id="btn-listas" class="btn" href="listas.php" data-tooltip="Gestionar las listas participantes">📑 Listas</a>
    <a id="btn-eleccion" class="btn" href="eleccion.php" data-tooltip="Definir o cambiar la elección activa">🎯 Elección activa</a>
    <a id="btn-resultados" class="btn secondary" href="resultados.php" data-tooltip="Ver los resultados de la votación">📊 Resultados</a>
    <a id="btn-salir" class="btn" href="salir.php" data-tooltip="Cerrar sesión de administrador">🔓 Cerrar sesión</a>
  </div>
</main>

<div id="montti-container">
  <img src="../assets/img/monttis-hablando1.gif" alt="Montti">
  <div id="montti-tip">¡Pasa el cursor sobre un botón para recibir ayuda!</div>
</div>

<script>
  const logos = document.querySelectorAll(".logo-carousel img");
  let current = 0;
  setInterval(() => {
    logos[current].classList.remove("active");
    current = (current + 1) % logos.length;
    logos[current].classList.add("active");
  }, 3000);

  const monttiTip = document.getElementById("montti-tip");
  const tips = {
    "📋 Padrón": "Aquí puedes subir o editar el listado de votantes.",
    "👥 Candidatos": "Revisa y modifica quiénes se postulan.",
    "📑 Listas": "Agrupa candidatos en listas para la elección.",
    "🎯 Elección activa": "Configura qué elección está habilitada.",
    "📊 Resultados": "Mira los resultados en tiempo real.",
    "🔓 Cerrar sesión": "No olvides cerrar sesión antes de salir."
  };

  document.querySelectorAll("a.btn").forEach(btn => {
    btn.addEventListener("mouseenter", () => {
      monttiTip.innerText = tips[btn.innerText.trim()] || "Explora esta opción.";
    });
    btn.addEventListener("mouseleave", () => {
      monttiTip.innerText = "¡Pasa el cursor sobre un botón para recibir ayuda!";
    });
  });

  const driver = window.driver.js.driver;
  driver({
    showProgress: true,
    steps: [
      { element: '#btn-padron', popover: { title: 'Padrón', description: 'Carga o edita los votantes.' } },
      { element: '#btn-candidatos', popover: { title: 'Candidatos', description: 'Administra los candidatos registrados.' } },
      { element: '#btn-listas', popover: { title: 'Listas', description: 'Gestiona las listas que compiten.' } },
      { element: '#btn-eleccion', popover: { title: 'Elección activa', description: 'Activa o cambia una elección.' } },
      { element: '#btn-resultados', popover: { title: 'Resultados', description: 'Observa resultados de votación.' } },
      { element: '#btn-salir', popover: { title: 'Cerrar sesión', description: 'Finaliza tu sesión como admin.' } }
    ]
  }).drive();
</script>
</body>
</html>
