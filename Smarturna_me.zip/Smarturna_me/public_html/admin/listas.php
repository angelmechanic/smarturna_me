<?php
require_once __DIR__ . '/../../lib/auth.php';
require_admin();
$pdo = db();
$msg = '';

// Acciones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) exit('CSRF inválido');

  // Eliminar
  if (isset($_POST['delete_id'])) {
    $id = (int)$_POST['delete_id'];
    $pdo->prepare('DELETE FROM listas WHERE id = ?')->execute([$id]);
    $msg = 'Lista eliminada.';

  // Editar
  } elseif (isset($_POST['edit_id'])) {
    $id = (int)$_POST['edit_id'];
    $nombre = trim($_POST['nombre'] ?? '');
    $eslogan = trim($_POST['eslogan'] ?? '');
    $activa = isset($_POST['activa']) ? 1 : 0;

    if ($nombre) {
      $pdo->prepare('UPDATE listas SET nombre = ?, eslogan = ?, activa = ? WHERE id = ?')
          ->execute([$nombre, $eslogan, $activa, $id]);
      $msg = 'Lista actualizada.';
    }

  // Agregar
  } else {
    $eleccion_id = (int)($_POST['eleccion_id'] ?? 1);
    $nombre = trim($_POST['nombre'] ?? '');
    $eslogan = trim($_POST['eslogan'] ?? '');
    if ($nombre) {
      $pdo->prepare('INSERT INTO listas (eleccion_id, nombre, eslogan) VALUES (?,?,?)')
          ->execute([$eleccion_id, $nombre, $eslogan]);
      $msg = 'Lista agregada.';
    }
  }
}

$elecciones = $pdo->query('SELECT id, nombre FROM elecciones ORDER BY id DESC')->fetchAll();
$listas = $pdo->query('
  SELECT l.id, l.nombre, l.eslogan, l.activa, e.nombre as eleccion 
  FROM listas l 
  JOIN elecciones e ON e.id = l.eleccion_id 
  ORDER BY e.id DESC
')->fetchAll();
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Listas</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<main class="container">
  <div class="card" id="form-agregar-lista">
    <h2>Agregar nueva lista</h2>
    <?php if ($msg): ?><div class="success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <label>Elección</label>
      <select class="input" name="eleccion_id">
        <?php foreach ($elecciones as $e): ?>
          <option value="<?= (int)$e['id'] ?>"><?= (int)$e['id'] ?> - <?= htmlspecialchars($e['nombre']) ?></option>
        <?php endforeach; ?>
      </select>
      <label>Nombre</label>
      <input class="input" name="nombre" required>
      <label>Eslogan</label>
      <input class="input" name="eslogan">
      <button class="btn" id="btn-agregar-lista" style="margin-top:10px">Agregar</button>
    </form>
  </div>

  <div class="card" id="tabla-listas">
    <h3>Listas registradas</h3>
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Elección</th><th>Nombre</th><th>Eslogan</th><th>Activa</th><th>Editar</th><th>Eliminar</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($listas as $l): ?>
        <tr>
          <form method="post">
            <td><?= (int)$l['id'] ?><input type="hidden" name="edit_id" value="<?= (int)$l['id'] ?>"></td>
            <td><?= htmlspecialchars($l['eleccion']) ?></td>
            <td><input class="input" name="nombre" value="<?= htmlspecialchars($l['nombre']) ?>" required></td>
            <td><input class="input" name="eslogan" value="<?= htmlspecialchars($l['eslogan']) ?>"></td>
            <td><input type="checkbox" name="activa" <?= $l['activa'] ? 'checked' : '' ?>></td>
            <td>
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <button class="btn btn-guardar-lista">💾</button>
            </td>
          </form>
          <td>
            <form method="post" onsubmit="return confirm('¿Eliminar esta lista?');">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
              <input type="hidden" name="delete_id" value="<?= (int)$l['id'] ?>">
              <button class="btn red btn-eliminar-lista">🗑</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</main>

<?php
$montti_path = __DIR__ . '/../montti.php';
if (file_exists($montti_path)) require $montti_path;
?>
</body>
</html>
