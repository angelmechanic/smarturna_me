<?php
require_once __DIR__ . '/../../lib/auth.php';
require_admin();

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=resultados_eleccion.xls");

$pdo = db();

// Obtener resultados agrupados por lista
$st = $pdo->query("
    SELECT 
        e.nombre AS eleccion,
        l.nombre AS lista,
        COUNT(v.id) AS votos
    FROM votos v
    JOIN listas l ON v.lista_id = l.id
    JOIN elecciones e ON l.eleccion_id = e.id
    GROUP BY l.id
    ORDER BY votos DESC
");

$resultados = $st->fetchAll();

echo "<table border='1'>";
echo "<tr><th>Elección</th><th>Lista</th><th>Votos</th></tr>";

foreach ($resultados as $r) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($r['eleccion']) . "</td>";
    echo "<td>" . htmlspecialchars($r['lista']) . "</td>";
    echo "<td>" . (int)$r['votos'] . "</td>";
    echo "</tr>";
}

echo "</table>";
