<?php
require_once __DIR__ . '/../../lib/auth.php';
require_admin();
$pdo = db();
$msg = '';

// Obtener datos FK
$cursos = $pdo->query('SELECT id, nombre FROM cursos ORDER BY id')->fetchAll();
$cargos = $pdo->query('SELECT id, nombre FROM cargos ORDER BY id')->fetchAll();

// Procesamiento POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) exit('CSRF inválido');

  if (isset($_POST['delete_id'])) {
    $id = (int)$_POST['delete_id'];
    $pdo->prepare('DELETE FROM candidatos WHERE id = ?')->execute([$id]);
    $msg = '✅ Candidato eliminado correctamente.';

  } elseif (isset($_POST['edit_id'])) {
    $id = (int)$_POST['edit_id'];
    $nombre = trim($_POST['nombre'] ?? '');
    $cargo_id = (int)($_POST['cargo_id'] ?? 0);
    $curso_id = (int)($_POST['curso_id'] ?? 0);
    $lista_id = (int)($_POST['lista_id'] ?? 0);

    if ($nombre && $cargo_id && $curso_id && $lista_id) {
      $stmt = $pdo->prepare('UPDATE candidatos SET nombre = ?, cargo_id = ?, curso_id = ?, lista_id = ? WHERE id = ?');
      $stmt->execute([$nombre, $cargo_id, $curso_id, $lista_id, $id]);
      $msg = '✅ Candidato actualizado correctamente.';
    } else {
      $msg = '⚠️ Todos los campos son obligatorios.';
    }

  } elseif (isset($_POST['lista_id'])) {
    $lista_id = (int)$_POST['lista_id'];
    $nombre = trim($_POST['nombre'] ?? '');
    $cargo_id = (int)($_POST['cargo_id'] ?? 0);
    $curso_id = (int)($_POST['curso_id'] ?? 0);

    $stmt = $pdo->prepare('SELECT eleccion_id FROM listas WHERE id = ?');
    $stmt->execute([$lista_id]);
    $eleccion_id = $stmt->fetchColumn();

    if ($lista_id && $nombre && $cargo_id && $curso_id && $eleccion_id !== false) {
      $stmt = $pdo->prepare('INSERT INTO candidatos (lista_id, nombre, cargo_id, curso_id, eleccion_id) VALUES (?, ?, ?, ?, ?)');
      $stmt->execute([$lista_id, $nombre, $cargo_id, $curso_id, $eleccion_id]);
      $msg = '✅ Candidato agregado correctamente.';
    } else {
      $msg = '⚠️ Error: campos incompletos o lista inexistente.';
    }
  }
}

$listas = $pdo->query('
  SELECT l.id, l.nombre, l.eslogan, e.nombre AS eleccion 
  FROM listas l 
  JOIN elecciones e ON l.eleccion_id = e.id 
  ORDER BY l.id DESC
')->fetchAll();

$candidatos = $pdo->query('
  SELECT c.id, c.nombre, c.cargo_id, c.curso_id,
         l.nombre AS lista, l.id AS lista_id 
  FROM candidatos c 
  JOIN listas l ON c.lista_id = l.id 
  ORDER BY l.id DESC, c.nombre
')->fetchAll();
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Gestor de Candidatos</title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<main class="container">
  <img src="../assets/img/Logo_colegio_ebm.png" class="logo-ebm" alt="Logo Colegio Ena Bellemans Montti">
  <div class="card">
    <h2>Agregar candidato</h2>
    <?php if ($msg): ?><div class="success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
      <label>Lista</label>
      <select class="input" name="lista_id" required>
        <option value="">Seleccione una lista</option>
        <?php foreach ($listas as $l): ?>
          <option value="<?= (int)$l['id'] ?>"><?= htmlspecialchars($l['nombre']) ?> (<?= htmlspecialchars($l['eleccion']) ?>)</option>
        <?php endforeach; ?>
      </select>
      <label>Nombre</label>
      <input class="input" name="nombre" required>
      <label>Cargo</label>
      <select class="input" name="cargo_id" required>
        <option value="">Seleccione un cargo</option>
        <?php foreach ($cargos as $car): ?>
          <option value="<?= $car['id'] ?>"><?= htmlspecialchars($car['nombre']) ?></option>
        <?php endforeach; ?>
      </select>
      <label>Curso</label>
      <select class="input" name="curso_id" required>
        <option value="">Seleccione un curso</option>
        <?php foreach ($cursos as $cur): ?>
          <option value="<?= $cur['id'] ?>"><?= htmlspecialchars($cur['nombre']) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn" style="margin-top:10px">Agregar</button>
    </form>
  </div>

  <div class="card">
    <h3>Listado de candidatos</h3>
    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>ID</th><th>Lista</th><th>Nombre</th><th>Cargo</th><th>Curso</th><th>Editar</th><th>Eliminar</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($candidatos as $c): ?>
            <tr>
              <form method="post">
                <td data-label="ID">
                  <?= (int)$c['id'] ?>
                  <input type="hidden" name="edit_id" value="<?= (int)$c['id'] ?>">
                </td>
                <td data-label="Lista">
                  <select class="input" name="lista_id" required>
                    <?php foreach ($listas as $l): ?>
                      <option value="<?= $l['id'] ?>" <?= $l['id'] == $c['lista_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($l['nombre']) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </td>
                <td data-label="Nombre">
                  <input class="input" name="nombre" value="<?= htmlspecialchars($c['nombre']) ?>" required>
                </td>
                <td data-label="Cargo">
                  <select class="input" name="cargo_id" required>
                    <?php foreach ($cargos as $car): ?>
                      <option value="<?= $car['id'] ?>" <?= $car['id'] == $c['cargo_id'] ? 'selected' : '' ?>><?= htmlspecialchars($car['nombre']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </td>
                <td data-label="Curso">
                  <select class="input" name="curso_id" required>
                    <?php foreach ($cursos as $cur): ?>
                      <option value="<?= $cur['id'] ?>" <?= $cur['id'] == $c['curso_id'] ? 'selected' : '' ?>><?= htmlspecialchars($cur['nombre']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </td>
                <td data-label="Editar">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                  <button class="btn">✍️</button>
                </td>
              </form>
              <td data-label="Eliminar">
                <form method="post" onsubmit="return confirm('¿Eliminar este candidato?');">
                  <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                  <input type="hidden" name="delete_id" value="<?= (int)$c['id'] ?>">
                  <button class="btn red">🗑</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<?php
$montti_path = __DIR__ . '/../montti.php';
if (file_exists($montti_path)) require $montti_path;
?>
</body>
</html>
