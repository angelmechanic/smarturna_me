<?php
require_once __DIR__ . '/../lib/auth.php';
$cfg = require __DIR__ . '/../config.php';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title><?= htmlspecialchars($cfg['app']['name']) ?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header>
  <div class="container">
    <h1><?= htmlspecialchars($cfg['app']['name']) ?></h1>
    <div>Votaciones escolares seguras y rápidas</div>
  </div>
</header>

<main class="container">
  <div class="row">
    <div class="col">
      <div class="card">
        <h2>Ingresar para Votar</h2>
        <form method="post" action="login_votante.php">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <label>RUT (sin puntos, con guion)</label>
          <input class="input" name="rut" placeholder="12.345.678-9" required>
          <label>PIN</label>
          <input class="input" name="pin" type="password" placeholder="PIN entregado por TRICEL" required>
          <div style="margin-top:12px">
            <button class="btn" type="submit">Ingresar</button>
          </div>
        </form>
      </div>
    </div>
    <div class="col">
      <div class="card">
        <h2>Administración</h2>
        <p>Acceso exclusivo para el equipo TRICEL / Dirección.</p>
        <a class="btn secondary" href="admin/login.php">Entrar a Administración</a>
      </div>
    </div>
  </div>
</main>

<footer>
  <?= date('Y') ?> © <?= htmlspecialchars($cfg['app']['name']) ?>
</footer>

<?php require_once __DIR__ . '/montti.php'; ?>

<!-- Overlay con animación de Montti -->
<div id="spinner-overlay">
  <div id="spinner-box">
    <img src="assets/img/monttis-hablando1.gif" alt="Montti hablando">
    <p id="spinner-text">Preparando sistema de votación…</p>
  </div>
</div>

<style>
  #spinner-overlay {
    display: none;
    position: fixed;
    z-index: 99999;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.75);
    justify-content: center;
    align-items: center;
  }

  #spinner-box {
    text-align: center;
    background: #222;
    color: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 0 12px #000;
    max-width: 300px;
  }

  #spinner-box img {
    width: 90px;
    margin-bottom: 15px;
  }

  #spinner-box p {
    font-size: 16px;
  }

  @media (max-width: 768px) {
    #spinner-box img { width: 70px; }
    #spinner-box p { font-size: 14px; }
  }
</style>

<script>
document.querySelector('form[action="login_votante.php"]').addEventListener('submit', function(e) {
  e.preventDefault();

  const overlay = document.getElementById('spinner-overlay');
  const text = document.getElementById('spinner-text');
  overlay.style.display = 'flex';

  const frases = [
    '🔐 Validando identidad...',
    '📦 Colocando las urnas...',
    '🧾 Pasando lista...',
    '⚙️ Montando sistema de votación...',
    '✅ ¡Todo listo! Puedes votar.'
  ];

  let index = 0;

  const ciclo = setInterval(() => {
    text.textContent = frases[index];
    index++;

    if (index >= frases.length) {
      clearInterval(ciclo);
      setTimeout(() => {
        e.target.submit();
      }, 1000);
    }
  }, 1000);
});
</script>

</body>
</html>
