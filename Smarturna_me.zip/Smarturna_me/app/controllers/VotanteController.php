

<?php
session_start();

require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../models/Candidato.php';
require_once __DIR__ . '/../models/Lista.php';
require_once __DIR__ . '/../models/Voto.php';
require_once __DIR__ . '/../models/Eleccion.php';


class VotanteController {
public static function votar() {
require_login();
$pdo = db();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lista_id'])) {
	if (!isset($_SESSION['votante'])) {
		// Handle missing session data
		http_response_code(400);
		echo "Error: Votante no autenticado.";
		return;
	}
	$rut = $_SESSION['votante'];
	$lista_id = (int)$_POST['lista_id'];
	Voto::registrar($pdo, $rut, $lista_id);
	include __DIR__ . '/../../public_html/voto_confirmado.php';
	return;
}
include __DIR__ . '/../../public_html/voto_confirmado.php';
return;
}


include __DIR__ . '/../../public_html/votar.php';
}


public static function resultados() {
$pdo = db();
$resultados = Lista::resultados($pdo);
include __DIR__ . '/../../public_html/resultados.php';
}
}