require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../models/Votante.php';


class AuthController {
public static function login() {
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
$rut = $_POST['rut'] ?? '';
$clave = $_POST['clave'] ?? '';
if (Votante::verificar($rut, $clave)) {
$_SESSION['votante'] = $rut;
header('Location: votar.php');
exit;
}
$error = 'Credenciales inválidas';
}
include __DIR__ . '/../../public_html/login.php';
}

public static function logout() {
session_start();
session_destroy();
header('Location: login.php');
}
}