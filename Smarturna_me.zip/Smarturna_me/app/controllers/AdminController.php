<?php
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../models/Candidato.php';
require_once __DIR__ . '/../models/Lista.php';
require_once __DIR__ . '/../models/Eleccion.php';
require_once __DIR__ . '/../models/Voto.php';
require_once __DIR__ . '/../models/Votante.php';

class AdminController {
	public static function panel() {
		require_admin();
		$pdo = db();
		$padron = Votante::count($pdo);
		$candidatos = Candidato::count($pdo);
		$votos = Voto::count($pdo);
		$listas = Lista::count($pdo);
		include __DIR__ . '/../../public_html/admin/panel.php';
	}
}